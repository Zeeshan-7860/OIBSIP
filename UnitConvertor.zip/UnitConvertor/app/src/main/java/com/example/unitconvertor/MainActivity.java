package com.example.unitconvertor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
EditText editText,editText2;
TextView textView,textView2;

Spinner spinner,spinner2,spinner3,spinner4;
Button button,button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.Edit1);
        editText2 = findViewById(R.id.Edit2);
        textView = findViewById(R.id.text1);
        textView2 = findViewById(R.id.text2);
        button = findViewById(R.id.btn1);
        button2 = findViewById(R.id.btn2);
        spinner = findViewById(R.id.spinner1);
        spinner2 = findViewById(R.id.spinner2);
        spinner3 = findViewById(R.id.spinner3);
        spinner4 = findViewById(R.id.spinner4);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.mass, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner2.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.length, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter1);
        spinner4.setAdapter(adapter1);

        button.setOnClickListener(v -> {
            if (spinner.getSelectedItem().toString().equals("Kilogram") && spinner2.getSelectedItem().toString().equals("Kilogram")) {
                String s = editText.getText().toString();
                double a = Double.parseDouble(s);
                double b = a;
                String c = String.valueOf(b);
                textView.setText(c);
            }
            if (spinner.getSelectedItem().toString().equals("Kilogram") && spinner2.getSelectedItem().toString().equals("Gram")) {
                String s = editText.getText().toString();
                double a = Double.parseDouble(s);
                double b = a * 1000;
                String c = String.valueOf(b);
                textView.setText(c);
            }
            if (spinner.getSelectedItem().toString().equals("Kilogram") && spinner2.getSelectedItem().toString().equals("Pound")) {
                String s = editText.getText().toString();
                double a = Double.parseDouble(s);
                double b = a * 2.205;
                String c = String.valueOf(b);
                textView.setText(c);
            }
            if (spinner.getSelectedItem().toString().equals("Gram") && spinner2.getSelectedItem().toString().equals("Kilogram")) {
                String s = editText.getText().toString();
                double a = Double.parseDouble(s);
                double b = a / 1000;
                String c = String.valueOf(b);
                textView.setText(c);
            }
            if (spinner.getSelectedItem().toString().equals("Gram") && spinner2.getSelectedItem().toString().equals("Gram")) {
                String s = editText.getText().toString();
                double a = Double.parseDouble(s);
                double b = a;
                String c = String.valueOf(b);
                textView.setText(c);
            }
            if (spinner.getSelectedItem().toString().equals("Gram") && spinner2.getSelectedItem().toString().equals("Pound")) {
                String s = editText.getText().toString();
                double a = Double.parseDouble(s);
                double b = a / 454;
                String c = String.valueOf(b);
                textView.setText(c);
            }
            if (spinner.getSelectedItem().toString().equals("Pound") && spinner2.getSelectedItem().toString().equals("Kilogram")) {
                String s = editText.getText().toString();
                double a = Double.parseDouble(s);
                double b = a / 2.205;
                String c = String.valueOf(b);
                textView.setText(c);
            }
            if (spinner.getSelectedItem().toString().equals("Pound") && spinner2.getSelectedItem().toString().equals("Gram")) {
                String s = editText.getText().toString();
                double a = Double.parseDouble(s);
                double b = a * 454;
                String c = String.valueOf(b);
                textView.setText(c);
            }
            if (spinner.getSelectedItem().toString().equals("Pound") && spinner2.getSelectedItem().toString().equals("Pound")) {
                String s = editText.getText().toString();
                double a = Double.parseDouble(s);
                double b = a;
                String c = String.valueOf(b);
                textView.setText(c);
            }
        });


        button2.setOnClickListener(v -> {
            if (spinner3.getSelectedItem().toString().equals("Kilometer") && spinner4.getSelectedItem().toString().equals("Kilometer")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Kilometer") && spinner4.getSelectedItem().toString().equals("Meter")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a * 1000;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Kilometer") && spinner4.getSelectedItem().toString().equals("Centimeter")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a * 100000;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Kilometer") && spinner4.getSelectedItem().toString().equals("Inch")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a * 39370;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Meter") && spinner4.getSelectedItem().toString().equals("Kilometer")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a / 1000;
                String c = String.valueOf(b);
                textView2.setText(c);
            }

            if (spinner3.getSelectedItem().toString().equals("Meter") && spinner4.getSelectedItem().toString().equals("Meter")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Meter") && spinner4.getSelectedItem().toString().equals("Centimeter")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a * 100;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Meter") && spinner4.getSelectedItem().toString().equals("Inch")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a * 39.37;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Centimeter") && spinner4.getSelectedItem().toString().equals("Kilometer")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a / 100000;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Centimeter") && spinner4.getSelectedItem().toString().equals("Meter")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a / 100;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Centimeter") && spinner4.getSelectedItem().toString().equals("Centimeter")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Centimeter") && spinner4.getSelectedItem().toString().equals("Inch")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a / 2.54;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Inch") && spinner4.getSelectedItem().toString().equals("Kilometer")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a / 39370;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Inch") && spinner4.getSelectedItem().toString().equals("Meter")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a / 39.37;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Inch") && spinner4.getSelectedItem().toString().equals("Centimeter")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a * 2.54;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
            if (spinner3.getSelectedItem().toString().equals("Inch") && spinner4.getSelectedItem().toString().equals("Inch")) {
                String s = editText2.getText().toString();
                double a = Double.parseDouble(s);
                double b = a;
                String c = String.valueOf(b);
                textView2.setText(c);
            }
        });

    }

}